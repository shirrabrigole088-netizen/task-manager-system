/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utils;

import java.io.File;
import java.io.IOException;

/**
 *
 * @author jheso
 */
public class FileDBHelper {
    public static final String DIRECTORY = "app/data/";
    
    public static String createDirectory(){
        //create dir
        File directory = new File(DIRECTORY);
        if (!directory.exists()) {
            //creates the directory
            if(directory.mkdirs()){
                System.out.println("System directories created.");
            } else {
                System.out.println("Error creating directories");
                return null;
            }
        } else {
            System.out.println("System directories already created");
        }
        return DIRECTORY;
    }
    
    public static String getDirectory(){
        return DIRECTORY;
    }
    
    public static String createFile(String filePath){
        File f = new File(DIRECTORY + filePath);
        String fullPath = null;
        try {
            if (f.createNewFile()) {
                System.out.println("File created.");
                fullPath = f.getPath();
            } else {
                System.out.println("File already existed");
                fullPath = f.getPath();
            }
        } catch (IOException e) {
            System.out.println("Create File error: " + e);
        }
        return fullPath;
    }
}
