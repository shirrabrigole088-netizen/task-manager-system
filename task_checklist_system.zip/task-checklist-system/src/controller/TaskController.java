package controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import model.Task;
import model.TaskManager;
import view.MainUI;

public class TaskController {

    /** Sorting options shown in the Sort menu. NEWEST is the default. */
    public enum SortMode {
        NEWEST("Newest to Oldest"),
        OLDEST("Oldest to Newest"),
        PENDING_FIRST("Pending First"),
        PRIORITY("High Priority First");

        private final String label;
        SortMode(String label) { this.label = label; }
        @Override public String toString() { return label; }
    }

    private final TaskManager model;
    private MainUI view;
    private SortMode sortMode = SortMode.NEWEST;

    public TaskController(TaskManager model) {
        this.model = model;
    }

    public void setView(MainUI view) {
        this.view = view;
    }

    public SortMode getSortMode() { return sortMode; }

    public void setSortMode(SortMode mode) {
        this.sortMode = mode;
        refreshView();
    }

    /** Adds a new task (createdAt is set automatically). */
    public boolean handleAddTask(String title, String desc, String priority, LocalDate dueDate) {
        if (title == null || title.trim().isEmpty() || priority == null) {
            return false;
        }
        Task task = new Task(title.trim(), desc == null ? "" : desc.trim(), priority, dueDate);
        model.addTask(task);
        if (model.saveTasks() == -1) {
            model.deleteTask(task.getTaskId()); // undo, keep memory and file consistent
            return false;
        }
        refreshView();
        return true;
    }

    public boolean handleUpdateTask(String id, String title, String desc, String priority, LocalDate dueDate) {
        if (id == null || title == null || title.trim().isEmpty() || priority == null) {
            return false;
        }
        Task task = model.findTask(id);
        if (task == null) {
            return false;
        }
        task.setTitle(title.trim());
        task.setDescription(desc == null ? "" : desc.trim());
        task.setPriority(priority);
        task.setDueDate(dueDate);
        if (model.saveTasks() == -1) {
            return false;
        }
        refreshView();
        return true;
    }

    /** Called when the checkbox in the table is ticked or unticked. */
    public boolean handleToggleDone(String id, boolean done) {
        Task task = model.findTask(id);
        if (task == null) {
            return false;
        }
        task.setCompleted(done);
        if (model.saveTasks() == -1) {
            return false;
        }
        refreshView();
        return true;
    }

    public boolean handleDeleteTask(String id) {
        Task task = model.deleteTask(id);
        if (task == null) {
            return false;
        }
        model.saveTasks();
        refreshView();
        return true;
    }

    /** @return how many completed tasks were removed */
    public int handleDeleteCompleted() {
        List<String> ids = new ArrayList<>();
        for (Task t : model.findAll().values()) {
            if (t.isCompleted()) ids.add(t.getTaskId());
        }
        for (String id : ids) {
            model.deleteTask(id);
        }
        if (!ids.isEmpty()) {
            model.saveTasks();
            refreshView();
        }
        return ids.size();
    }

    /** All tasks, sorted using the current SortMode (newest first by default). */
    public List<Task> getAllTasks() {
        List<Task> list = new ArrayList<>(model.findAll().values());
        list.sort(comparatorFor(sortMode));
        return list;
    }

    private Comparator<Task> comparatorFor(SortMode mode) {
        Comparator<Task> newestFirst = (a, b) -> b.getCreatedAt().compareTo(a.getCreatedAt());
        switch (mode) {
            case OLDEST:
                return (a, b) -> a.getCreatedAt().compareTo(b.getCreatedAt());
            case PENDING_FIRST:
                return (a, b) -> {
                    if (a.isCompleted() != b.isCompleted()) return a.isCompleted() ? 1 : -1;
                    return newestFirst.compare(a, b);
                };
            case PRIORITY:
                return (a, b) -> {
                    if (a.getPriorityRank() != b.getPriorityRank())
                        return b.getPriorityRank() - a.getPriorityRank();
                    return newestFirst.compare(a, b);
                };
            case NEWEST:
            default:
                return newestFirst;
        }
    }

    public Task getTaskDetails(String id) {
        return model.findTask(id);
    }

    public int getTotalCount() {
        return model.findAll().size();
    }

    public int getDoneCount() {
        int n = 0;
        for (Task t : model.findAll().values()) {
            if (t.isCompleted()) n++;
        }
        return n;
    }

    private void refreshView() {
        if (this.view != null) {
            this.view.refreshTasks();
        }
    }
}
