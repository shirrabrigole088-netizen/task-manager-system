package view;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;
import model.Task;

public class TaskTableModel extends AbstractTableModel {

    /** Notified when the user ticks or unticks the "Done" checkbox. */
    public interface DoneListener {
        void onDoneChanged(String taskId, boolean done);
    }

    private List<Task> tasks;
    private DoneListener doneListener;

    private final String[] COLUMN_NAMES = {"Done", "Task", "Description", "Priority", "Due", "Created"};
    private final DateTimeFormatter createdFormat = DateTimeFormatter.ofPattern("MMM dd, yyyy hh:mm a");

    public TaskTableModel() {
        this.tasks = new ArrayList<>();
    }

    public void setDoneListener(DoneListener listener) {
        this.doneListener = listener;
    }

    @Override
    public int getRowCount() {
        return this.tasks.size();
    }

    @Override
    public int getColumnCount() {
        return this.COLUMN_NAMES.length;
    }

    @Override
    public String getColumnName(int column) {
        return this.COLUMN_NAMES[column];
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        return columnIndex == 0 ? Boolean.class : String.class;
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return columnIndex == 0; // only the checkbox is editable
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Task task = tasks.get(rowIndex);
        return switch (columnIndex) {
            case 0 -> task.isCompleted();
            case 1 -> task.getTitle();
            case 2 -> task.getDescription();
            case 3 -> task.getPriority();
            case 4 -> task.getDueDate() == null ? "-" : task.getDueDate().toString();
            case 5 -> task.getCreatedAt().format(createdFormat);
            default -> null;
        };
    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        if (columnIndex == 0 && aValue instanceof Boolean && doneListener != null) {
            doneListener.onDoneChanged(tasks.get(rowIndex).getTaskId(), (Boolean) aValue);
        }
    }

    public void setTasks(List<Task> tasks) {
        this.tasks = tasks;
        fireTableDataChanged();
    }

    public String getTaskId(int rowIndex) {
        return tasks.get(rowIndex).getTaskId();
    }

    public boolean isDone(int rowIndex) {
        return tasks.get(rowIndex).isCompleted();
    }
}
