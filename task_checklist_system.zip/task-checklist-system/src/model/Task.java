package model;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Random;

public class Task implements Serializable {
    private static final long serialVersionUID = 1L;

    private final String taskId;
    private String title;
    private String description;
    private String priority;      // Low, Medium, High
    private LocalDate dueDate;    // optional, may be null
    private boolean completed;
    private final LocalDateTime createdAt;

    public Task(String title, String description, String priority, LocalDate dueDate) {
        this.title = title;
        this.description = description;
        this.priority = priority;
        this.dueDate = dueDate;
        this.completed = false;
        this.createdAt = LocalDateTime.now();
        this.taskId = generateRandomId();
    }

    private String generateRandomId() {
        int num = new Random().nextInt(9999);
        long timestamp = System.currentTimeMillis() % 1000000;
        return String.format("%d-%d-%04d", LocalDate.now().getYear(), timestamp, num);
    }

    public String getTaskId() { return taskId; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getPriority() { return priority; }
    public void setPriority(String priority) { this.priority = priority; }
    public LocalDate getDueDate() { return dueDate; }
    public void setDueDate(LocalDate dueDate) { this.dueDate = dueDate; }
    public boolean isCompleted() { return completed; }
    public void setCompleted(boolean completed) { this.completed = completed; }
    public LocalDateTime getCreatedAt() { return createdAt; }

    /** High = 3, Medium = 2, Low = 1 (used for sorting). */
    public int getPriorityRank() {
        if ("High".equals(priority)) return 3;
        if ("Medium".equals(priority)) return 2;
        return 1;
    }

    @Override
    public String toString() {
        return "Task{" + "taskId=" + taskId + ", title=" + title + ", priority=" + priority
                + ", dueDate=" + dueDate + ", completed=" + completed + ", createdAt=" + createdAt + '}';
    }
}
