package model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import utils.FileDBHelper;

public class TaskManager {
    private HashMap<String, Task> tasks;
    private final String FILE_PATH = "tasks.ser";

    public TaskManager() {
        tasks = new HashMap<>();
        FileDBHelper.createFile(FILE_PATH);
    }

    public void addTask(Task task) {
        tasks.put(task.getTaskId(), task);
    }

    public Task findTask(String id) {
        return tasks.get(id);
    }

    public Task deleteTask(String id) {
        return tasks.remove(id);
    }

    public HashMap<String, Task> findAll() {
        return this.tasks;
    }

    public int saveTasks() {
        int errorCode = 0; // 0: success; -1: error
        try (FileOutputStream fos = new FileOutputStream(FileDBHelper.DIRECTORY + FILE_PATH);
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            oos.writeObject(tasks);
        } catch (IOException e) {
            errorCode = -1;
            System.out.println("Error: " + e);
        }
        return errorCode;
    }

    @SuppressWarnings("unchecked")
    public void loadTasks() {
        File file = new File(FileDBHelper.DIRECTORY + FILE_PATH);
        if (!file.exists() || file.length() == 0) {
            return; // first run: nothing to load yet
        }
        try (FileInputStream fis = new FileInputStream(file);
             ObjectInputStream ois = new ObjectInputStream(fis)) {
            this.tasks = (HashMap<String, Task>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error Read: " + e);
        }
    }
}
